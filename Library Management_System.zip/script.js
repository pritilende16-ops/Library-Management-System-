let books = [
    {
        id: 1,
        name: "Introduction to C Programming",
        author: "E. Balagurusamy",
        category: "Programming",
        quantity: 5
    },
    {
        id: 2,
        name: "Object Oriented Programming",
        author: "Robert Lafore",
        category: "Programming",
        quantity: 4
    },
    {
        id: 3,
        name: "Database Management System",
        author: "Raghu Ramakrishnan",
        category: "Database",
        quantity: 6
    },
    {
        id: 4,
        name: "Data Structures",
        author: "Seymour Lipschutz",
        category: "Computer Science",
        quantity: 3
    },
    {
        id: 5,
        name: "Computer Networks",
        author: "Andrew S. Tanenbaum",
        category: "Networking",
        quantity: 5
    },
    {
        id: 6,
        name: "Web Technology",
        author: "HTML, CSS & JavaScript",
        category: "Web Development",
        quantity: 7
    }
];

let issuedBooks = [];


/* LOGIN */

document.getElementById("loginForm").addEventListener("submit", function(event) {

    event.preventDefault();

    let username = document.getElementById("username").value.trim();
    let password = document.getElementById("password").value;

    let error = document.getElementById("loginError");

    if (username === "") {
        error.innerText = "Please enter username.";
        return;
    }

    if (password.length < 4) {
        error.innerText = "Password must contain at least 4 characters.";
        return;
    }

    error.innerText = "";

    document.getElementById("loginPage").style.display = "none";
    document.getElementById("mainPage").style.display = "block";

    displayBooks();
    updateDashboard();
    updateBookSelect();
});


/* DISPLAY BOOKS */

function displayBooks(bookList = books) {

    let container = document.getElementById("bookContainer");

    container.innerHTML = "";

    if (bookList.length === 0) {

        container.innerHTML =
            "<p style='text-align:center;'>No books found.</p>";

        return;
    }

    bookList.forEach(function(book) {

        let status = book.quantity > 0
            ? "Available"
            : "Not Available";

        let statusClass = book.quantity > 0
            ? "available"
            : "unavailable";

        container.innerHTML += `

            <div class="book-card">

                <div class="book-icon">📚</div>

                <h3>${book.name}</h3>

                <p><b>Author:</b> ${book.author}</p>

                <p><b>Category:</b> ${book.category}</p>

                <p>
                    <b>Quantity:</b> ${book.quantity}
                </p>

                <p class="${statusClass}">
                    ${status}
                </p>

            </div>

        `;
    });
}


/* SEARCH BOOK */

function searchBooks() {

    let search =
        document.getElementById("searchBook")
        .value
        .toLowerCase();

    let filteredBooks = books.filter(function(book) {

        return (
            book.name.toLowerCase().includes(search) ||
            book.author.toLowerCase().includes(search) ||
            book.category.toLowerCase().includes(search)
        );

    });

    displayBooks(filteredBooks);
}


/* BOOK SELECT */

function updateBookSelect() {

    let select =
        document.getElementById("bookSelect");

    select.innerHTML =
        '<option value="">-- Select Book --</option>';

    books.forEach(function(book) {

        if (book.quantity > 0) {

            select.innerHTML += `
                <option value="${book.id}">
                    ${book.name}
                </option>
            `;
        }

    });
}


/* ISSUE BOOK */

document.getElementById("issueForm").addEventListener("submit", function(event) {

    event.preventDefault();

    let studentName =
        document.getElementById("studentName").value.trim();

    let studentId =
        document.getElementById("studentId").value.trim();

    let bookId =
        Number(document.getElementById("bookSelect").value);

    let issueDate =
        document.getElementById("issueDate").value;

    let message =
        document.getElementById("issueMessage");

    if (!studentName || !studentId || !bookId || !issueDate) {

        message.style.color = "red";
        message.innerText = "Please fill all details.";

        return;
    }

    let book =
        books.find(function(item) {
            return item.id === bookId;
        });

    if (!book || book.quantity <= 0) {

        message.style.color = "red";
        message.innerText = "Book is not available.";

        return;
    }

    book.quantity--;

    issuedBooks.push({

        studentName: studentName,

        studentId: studentId,

        bookId: book.id,

        bookName: book.name,

        issueDate: issueDate,

        status: "Issued"

    });

    message.style.color = "green";

    message.innerText =
        "Book issued successfully!";

    document.getElementById("issueForm").reset();

    displayBooks();

    updateBookSelect();

    updateDashboard();

    displayIssuedBooks();

});


/* DISPLAY ISSUED BOOKS */

function displayIssuedBooks() {

    let table =
        document.getElementById("issuedTable");

    table.innerHTML = "";

    if (issuedBooks.length === 0) {

        table.innerHTML = `
            <tr>
                <td colspan="6">
                    No books issued yet.
                </td>
            </tr>
        `;

        return;
    }

    issuedBooks.forEach(function(item, index) {

        table.innerHTML += `

            <tr>

                <td>${item.studentName}</td>

                <td>${item.studentId}</td>

                <td>${item.bookName}</td>

                <td>${item.issueDate}</td>

                <td>${item.status}</td>

                <td>

                    ${
                        item.status === "Issued"

                        ? `<button
                            class="return-btn"
                            onclick="returnBook(${index})">
                            Return
                           </button>`

                        : "Returned"
                    }

                </td>

            </tr>

        `;

    });
}


/* RETURN BOOK */

function returnBook(index) {

    let issuedBook =
        issuedBooks[index];

    let book =
        books.find(function(item) {

            return item.id === issuedBook.bookId;

        });

    if (book) {

        book.quantity++;

    }

    issuedBook.status = "Returned";

    displayBooks();

    displayIssuedBooks();

    updateBookSelect();

    updateDashboard();

}


/* DASHBOARD */

function updateDashboard() {

    let totalBooks = books.reduce(
        function(total, book) {
            return total + book.quantity;
        },
        0
    );

    let issuedCount =
        issuedBooks.filter(function(item) {
            return item.status === "Issued";
        }).length;

    let totalBookTypes =
        books.length;

    document.getElementById("totalBooks").innerText =
        totalBookTypes;

    document.getElementById("totalStudents").innerText =
        issuedBooks.length;

    document.getElementById("issuedBooks").innerText =
        issuedCount;

    document.getElementById("availableBooks").innerText =
        totalBooks;
}


/* SCROLL TO BOOKS */

function scrollToBooks() {

    document.getElementById("books")
        .scrollIntoView({
            behavior: "smooth"
        });

}


/* LOGOUT */

function logout() {

    document.getElementById("mainPage").style.display = "none";

    document.getElementById("loginPage").style.display = "flex";

    document.getElementById("loginForm").reset();

    document.getElementById("loginError").innerText = "";

}


/* DEFAULT DATE */

window.addEventListener("load", function() {

    let today =
        new Date().toISOString().split("T")[0];

    document.getElementById("issueDate").value = today;

    displayIssuedBooks();

});